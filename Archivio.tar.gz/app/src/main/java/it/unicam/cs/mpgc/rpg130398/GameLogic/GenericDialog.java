package it.unicam.cs.mpgc.rpg130398.GameLogic;

import it.unicam.cs.mpgc.rpg130398.api.dialog.*;
import org.jspecify.annotations.NonNull;

import java.io.IOException;
import java.util.*;

public class GenericDialog implements Dialog {

    private final HashMap<Integer, DialogNode> nodes = new HashMap<>();         // id node -> node
    private final HashSet<Integer> visitedNodes = new HashSet<>();                  // id of already visited nodes
    private final HashSet<DialogNode.Connection> usedConnections = new HashSet<>(); // a set of all the used Connections
    private final ArrayList<String> unlockedFlags = new ArrayList<>();
    private DialogNode currentNode;

    public GenericDialog(ArrayList<DialogNode> nodes) {
        setup(nodes);
    }

    public GenericDialog(@NonNull DialogLoader loader) {
        try {
            loader.read();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        setup(loader.getNodes());
    }

    private void setup(@NonNull ArrayList<DialogNode> nodeList) {
        nodes.clear();
        for (DialogNode node : nodeList)
            nodes.put(node.getId(), node);
        currentNode = nodes.get(0); // The Start of the conversation is the node with id=0
        currentNode.markVisited();
        visitedNodes.clear();
    }

    @Override
    public ArrayList<DialogNode.Connection> getValidChoices() {
        ArrayList<DialogNode.Connection> result = new ArrayList<>();
        for (DialogNode.Connection connection : currentNode.getConnection())
            if (isAValidChoice(connection))
                result.add(connection);
        return result;
    }

    @Override
    public DialogNode getCurrentNode() {
        return currentNode;
    }

    @Override
    public boolean makeChoices(DialogNode.Connection connection) {
        if (!getValidChoices().contains(connection))
            return false;

        currentNode = nodes.get(connection.idOther());

        visitedNodes.add(currentNode.getId());
        usedConnections.add(connection);
        currentNode.markVisited();
        System.out.println(connection);
        onChoiceMade(connection);
        return true;
    }

    /**
     * This method is useful for superclass that extend this class
     * It is used to update optional DialogStates
     *
     * @param connection the choice made and valid
     */
    protected void onChoiceMade(DialogNode.Connection connection) {
        // default: nothing
    }

    @Override
    public DialogNode getNodeFromID(int id) {
        return nodes.get(id);
    }

    @Override
    public List<String> getCollectedFlags() {
        return unlockedFlags;
    }

    @Override
    public Set<Integer> getVisitedNodes() {
        return visitedNodes;
    }

    /**
     * A connection is a valid choice when it targets an existing node, has not
     * already been used (engine rule: no repeating the same connection, which
     * also prevents loops), and all of its {@link ConnectionRequirement}
     * are satisfied by the current state.
     */
    private boolean isAValidChoice(DialogNode.Connection connection) {
        if (!nodes.containsKey(connection.idOther()))
            return false;
        if (usedConnections.contains(connection))
            return false;
        return connection.isSatisfiedBy(this);
    }
}